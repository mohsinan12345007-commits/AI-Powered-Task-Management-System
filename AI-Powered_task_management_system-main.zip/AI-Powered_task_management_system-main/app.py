from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import joblib
import os

app = Flask(__name__, static_folder='frontend', static_url_path='')
CORS(app)

MODEL_PATH = "model.pkl"

# Try loading model (optional)
model = None
if os.path.exists(MODEL_PATH):
    try:
        model = joblib.load(MODEL_PATH)
        print("✅ Loaded model from", MODEL_PATH)
    except Exception as e:
        print("⚠️ Failed to load model:", e)
else:
    print("ℹ️ No model file found — using keyword-based AI labels.")

# Temporary in-memory storage
TASKS = []
TASK_ID_COUNTER = 1


@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')


@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    return jsonify(TASKS)


@app.route('/api/tasks', methods=['POST'])
def add_task():
    global TASK_ID_COUNTER
    data = request.get_json()
    title = data.get('title', '').strip()
    description = data.get('description', '').strip()

    if not title and not description:
        return jsonify({"error": "Title or description required"}), 400

    text = f"{title}. {description}"
    prediction = None

    # 1️⃣ Use trained model if available
    if model is not None:
        try:
            prediction = model.predict([text])[0]
        except Exception as e:
            print("Model prediction error:", e)
            prediction = None

    # 2️⃣ If no model — use simple AI-like keyword logic
    if prediction is None:
        text_lower = text.lower()
        if "error" in text_lower or "fix" in text_lower or "bug" in text_lower:
            prediction = "High Priority"
        elif "report" in text_lower or "review" in text_lower:
            prediction = "Normal"
        elif "update" in text_lower or "improve" in text_lower:
            prediction = "Low Priority"
        else:
            prediction = "General Task"

    task = {
        "id": TASK_ID_COUNTER,
        "title": title,
        "description": description,
        "ai_label": prediction
    }

    TASK_ID_COUNTER += 1
    TASKS.append(task)
    return jsonify(task), 201


if __name__ == '__main__':
    app.run(debug=True, port=5000)
