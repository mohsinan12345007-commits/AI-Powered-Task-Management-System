document.getElementById("task-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const title = document.getElementById("title").value.trim();
  const description = document.getElementById("description").value.trim();
  const messageBox = document.getElementById("message");

  if (!title || !description) {
    messageBox.innerText = "❌ Please enter both title and description.";
    return;
  }

  try {
    const response = await fetch("/api/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description }),
    });

    const result = await response.json();

    if (result.error) {
      messageBox.innerText = "❌ " + result.error;
    } else {
      messageBox.innerText = `✅ Task added! AI label: ${result.ai_label}`;
      addTaskToList(result);
    }

    document.getElementById("title").value = "";
    document.getElementById("description").value = "";
  } catch (err) {
    console.error("Error:", err);
    messageBox.innerText = "⚠️ Server error. Please try again.";
  }
});

function addTaskToList(task) {
  const list = document.getElementById("task-list");
  const item = document.createElement("li");
  item.textContent = `${task.title} — ${task.description}  [AI: ${task.ai_label}]`;
  list.appendChild(item);
}
