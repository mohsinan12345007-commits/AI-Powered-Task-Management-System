# train.py
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
import argparse
import os

def load_data(csv_path, text_col='text', label_col='label'):
    df = pd.read_csv(csv_path)
    # Basic checks
    if text_col not in df.columns or label_col not in df.columns:
        raise ValueError(f"CSV must contain columns '{text_col}' and '{label_col}'. Found: {df.columns.tolist()}")
    df = df[[text_col, label_col]].dropna()
    return df[text_col].astype(str).tolist(), df[label_col].tolist()

def build_pipeline():
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(max_features=10000, ngram_range=(1,2))),
        ('clf', LogisticRegression(max_iter=1000))
    ])
    return pipeline

def train_and_save(csv_path, model_out='model.pkl', test_size=0.15, random_state=42, text_col='text', label_col='label'):
    X, y = load_data(csv_path, text_col=text_col, label_col=label_col)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y if len(set(y))>1 else None)
    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)

    # Evaluate
    preds = pipeline.predict(X_test)
    print("Classification report on holdout set:")
    print(classification_report(y_test, preds))

    # Save
    joblib.dump(pipeline, model_out)
    print(f"Saved model to {model_out}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train model from CSV")
    parser.add_argument('--csv', required=True, help='Path to CSV file with training data')
    parser.add_argument('--out', default='model.pkl', help='Output model path')
    parser.add_argument('--text_col', default='text', help='Name of the text column in CSV')
    parser.add_argument('--label_col', default='label', help='Name of the label column in CSV')
    args = parser.parse_args()

    if not os.path.exists(args.csv):
        raise FileNotFoundError(f"{args.csv} not found")
    train_and_save(args.csv, model_out=args.out, text_col=args.text_col, label_col=args.label_col)
